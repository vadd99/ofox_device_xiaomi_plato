Q2.b
